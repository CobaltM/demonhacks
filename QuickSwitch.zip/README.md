# demonhacks
## A tool to protect your privacy using google's face detector api
### Easy to use and non-intrusive to your focus, this app silently keeps you protected
### Options include toggling functionality, personal url, delay to close (in case a page is stuttering, increasing this value should help)
### Number to abide is the number of people that are allowed to be looking at your screen
### Exact abidation means that exclusively that number of people to abide are allowed (no more, no less)
### Closeness sensitivity requires a minimum distance from the camera for your screen not to be blocked (to turn this feature off, just set it to 0)